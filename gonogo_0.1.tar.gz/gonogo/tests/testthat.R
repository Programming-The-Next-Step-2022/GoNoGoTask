library(testthat)
library(gonogo)

test_check("gonogo")
