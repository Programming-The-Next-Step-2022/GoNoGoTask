#' Draws a screen
#'
#' @param txt A character string specifying the text to be printed on the screen
#' @param cex A numeric value specifying the font size (default is 1)
#' @param col A character string specifying the color of the text (default is black)
#'
#' @return Draws a screen corresponding to the specified values
#' @export
#'
#' @examples
drawScreen <- function(txt, cex=1, col="black") {
  plot(x=NA, y=NA, xlim=c(0,1), ylim=c(0,1), xaxt="n", yaxt="n", xlab="", ylab="")
  text(x=0.5, y=0.5, labels=txt, cex=cex)
}
# add errors