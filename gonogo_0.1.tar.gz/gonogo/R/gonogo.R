#' This package contains the Go-No Go Task.
#'
#' The package has x functions.
#'
#' @section Validate user's response:
#' \emph{validate_user_response} validates the user's response.
#'
#' @docType package
#' @name gonogo
#'
NULL
